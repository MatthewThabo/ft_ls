/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_realloc.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tmatlena <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/08/28 13:01:37 by tmatlena          #+#    #+#             */
/*   Updated: 2018/08/28 13:01:45 by tmatlena         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <stdio.h>
#include "../includes/libft.h"

void		*ft_realloc(void *ptr, int sizeofptr, int size)
{
	void	*newptr;

	newptr = (void *)malloc(sizeofptr + size);
	ft_memcpy(newptr, ptr, sizeofptr);
	free(ptr);
	return (newptr);
}
