/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tmatlena <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/08/28 12:22:31 by tmatlena          #+#    #+#             */
/*   Updated: 2018/08/28 12:22:37 by tmatlena         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <libft.h>

t_list		*ft_lstdup(t_list *src)
{
	t_list	*dst;

	dst = NULL;
	while (src)
	{
		ft_lstaddtail(&dst, ft_lstnew(src->content, src->content_size));
		src = src->next;
	}
	return (NULL);
}
