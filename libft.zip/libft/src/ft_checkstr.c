/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_checkstr.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tmatlena <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/08/28 11:50:47 by tmatlena          #+#    #+#             */
/*   Updated: 2018/08/28 11:50:54 by tmatlena         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <libft.h>

int		ft_checkstr(char *chars, char *cmp)
{
	int i;

	i = 0;
	if (chars == NULL)
		return (1);
	if (cmp == NULL)
		return (0);
	while (ft_strchr(chars, cmp[i]) && cmp[i] != '\0')
		i++;
	if (cmp[i] != '\0')
		return (0);
	return (1);
}
