/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstdelbyfunc.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tmatlena <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/08/28 12:18:44 by tmatlena          #+#    #+#             */
/*   Updated: 2018/08/28 12:18:50 by tmatlena         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/libft.h"
#include "../../includes/ft_ls.h"

void		ft_lstdelbyfunc(t_list **alst, void (*del)(void **content))
{
	t_list		**tmp;
	t_list		**tmp2;

	tmp = alst;
	while (*tmp)
	{
		if (del)
			del((&(*tmp)->content));
		tmp2 = tmp;
		tmp = &((*tmp)->next);
		ft_memdel((void**)tmp2);
	}
}
