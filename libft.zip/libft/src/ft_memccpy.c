/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memccpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tmatlena <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/08/28 12:28:12 by tmatlena          #+#    #+#             */
/*   Updated: 2018/08/28 12:28:16 by tmatlena         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/libft.h"

void	*ft_memccpy(void *dst, void const *src, int c, size_t n)
{
	size_t			i;

	i = 0;
	while (i < n)
	{
		*((uint8_t *)(dst + i)) = *((uint8_t *)(src + i));
		if (*(uint8_t *)(dst + i) == (uint8_t)c)
			return (dst + i + 1);
		i++;
	}
	return (NULL);
}
