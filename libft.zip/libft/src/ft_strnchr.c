/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strnchr.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tmatlena <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/08/28 14:31:10 by tmatlena          #+#    #+#             */
/*   Updated: 2018/08/28 14:31:14 by tmatlena         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/libft.h"

char	*ft_strnchr(const char *s, int c, int n)
{
	int		i;
	char	*str;

	i = 0;
	str = (char *)s;
	while (str[i] != c && str[i] != '\0' && i < n)
		i++;
	if ((str[i] == 0 || i == n) && c != 0)
		return (NULL);
	return (str + i);
}
