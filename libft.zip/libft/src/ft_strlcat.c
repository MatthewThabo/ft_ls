/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tmatlena <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/08/28 13:30:25 by tmatlena          #+#    #+#             */
/*   Updated: 2018/08/28 13:30:30 by tmatlena         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/libft.h"

size_t		ft_strlcat(char *dst, const char *src, size_t size)
{
	char	*str;
	size_t	toret;

	if (!(str = ft_memchr(dst, '\0', size)))
		return (size + ft_strlen(src));
	toret = (size_t)(str - dst) + ft_strlen(src);
	while ((size_t)(str - dst) < size - 1 && *src)
	{
		*str = *src;
		str++;
		src++;
	}
	*str = '\0';
	return (toret);
}
