/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memcmp.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tmatlena <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/08/28 12:30:38 by tmatlena          #+#    #+#             */
/*   Updated: 2018/08/28 12:30:44 by tmatlena         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/libft.h"

int		ft_memcmp(const void *s1, const void *s2, size_t n)
{
	size_t	i;

	i = 0;
	while (i < n)
	{
		if (*(uint8_t *)(s1 + i) != *(uint8_t *)(s2 + i))
			return (*(uint8_t *)(s1 + i) - *(uint8_t *)(s2 + i));
		i++;
	}
	return (0);
}
