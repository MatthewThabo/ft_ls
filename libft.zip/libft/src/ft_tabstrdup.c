/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_tabstrdup.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tmatlena <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/08/28 14:57:14 by tmatlena          #+#    #+#             */
/*   Updated: 2018/08/28 14:57:18 by tmatlena         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/libft.h"

char		**ft_tabstrdup(char **tab)
{
	int		i;
	char	**dup;

	i = 0;
	dup = NULL;
	while (tab[i])
		i++;
	if ((dup = (char **)malloc(sizeof(char *) * (i + 1))))
	{
		dup[i] = NULL;
		while (i--)
			dup[i] = ft_strdup(tab[i]);
	}
	return (dup);
}
