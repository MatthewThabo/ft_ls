/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_parse_file.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tmatlena <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/08/28 12:41:13 by tmatlena          #+#    #+#             */
/*   Updated: 2018/08/28 12:41:18 by tmatlena         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <libft.h>

t_list		*ft_parse_file(char *filename, char *chars)
{
	int		fd;
	t_list	*file;
	char	*line;

	fd = open(filename, O_RDONLY);
	if (!ft_strcmp(filename, "stdin"))
		fd = 0;
	if (fd == -1)
		return (NULL);
	file = NULL;
	line = NULL;
	while (get_next_line(fd, &line))
	{
		if (!ft_checkstr(chars, line))
		{
			ft_lstdel(&file);
			return (NULL);
		}
		else
			ft_lstaddtail(&file, ft_lstnew(line, ft_strlen(line) + 1));
		ft_memdel((void **)&line);
	}
	return (file);
}
