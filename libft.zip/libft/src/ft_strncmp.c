/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncmp.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tmatlena <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/08/28 14:32:03 by tmatlena          #+#    #+#             */
/*   Updated: 2018/08/28 14:32:08 by tmatlena         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/libft.h"

int		ft_strncmp(char const *s1, char const *s2, size_t n)
{
	size_t i;

	i = 0;
	if (n == 0)
		return (0);
	if (*s1 != '\0' && *s2 != '\0')
	{
		while (s1[i] == s2[i] && s1[i] != '\0' && s2[i] != '\0' && i != n)
			i++;
		if (i == n)
			return (0);
	}
	return (*(uint8_t *)(s1 + i) - *(uint8_t *)(s2 + i));
}
