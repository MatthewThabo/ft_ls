/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strndup.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tmatlena <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/08/28 14:34:21 by tmatlena          #+#    #+#             */
/*   Updated: 2018/08/28 14:34:25 by tmatlena         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/libft.h"

char	*ft_strndup(char *str, int n)
{
	char	*str2;
	int		len;

	len = ft_strlen(str);
	len = len < n ? len : n;
	str2 = (char *)malloc(sizeof(char) * (len + 1));
	str2[len] = '\0';
	ft_strncpy(str2, str, len);
	return (str2);
}
