/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_realloc_char.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tmatlena <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/08/28 13:03:03 by tmatlena          #+#    #+#             */
/*   Updated: 2018/08/28 13:03:59 by tmatlena         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/libft.h"

char	*ft_realloc_char(char *ptr, size_t size)
{
	char *newptr;

	newptr = (char *)malloc(sizeof(char) * size + 1);
	if (ptr != NULL)
	{
		ft_strcpy(newptr, ptr);
		free(ptr);
	}
	return (newptr);
}
