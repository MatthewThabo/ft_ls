/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tmatlena <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/08/28 13:17:46 by tmatlena          #+#    #+#             */
/*   Updated: 2018/08/28 13:17:51 by tmatlena         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/libft.h"

char	*ft_strdup(const char *s1)
{
	char *dest;

	dest = NULL;
	if (s1)
	{
		dest = ft_strnew(ft_strlen(s1));
		if (dest != NULL)
			ft_strcpy(dest, s1);
	}
	return (dest);
}
