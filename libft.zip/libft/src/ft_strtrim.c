/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strtrim.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tmatlena <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/08/28 14:51:37 by tmatlena          #+#    #+#             */
/*   Updated: 2018/08/28 14:51:42 by tmatlena         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/libft.h"

char	*ft_strtrim(char const *s)
{
	int		start;
	int		end;

	if (s == NULL)
		return (NULL);
	start = 0;
	end = ft_strlen(s) - 1;
	if (s != NULL)
	{
		while ((s[start] == ' ' || s[start] == '\n' || s[start] == '\t') &&
				s[start] != '\0')
			start++;
		while ((s[end] == ' ' || s[end] == '\n' || s[end] == '\t') && end != 0
				&& end > start)
			end--;
	}
	return (ft_strsub(s, start, end - start + 1));
}
