/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstdelfirst.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tmatlena <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/08/28 12:19:42 by tmatlena          #+#    #+#             */
/*   Updated: 2018/08/28 12:19:48 by tmatlena         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/libft.h"

void		ft_lstdelfirst(t_list **alst)
{
	t_list	*tmp;

	if (*alst && (*alst)->content)
	{
		tmp = (*alst)->next;
		free((*alst)->content);
		free(*alst);
		*alst = tmp;
	}
}
