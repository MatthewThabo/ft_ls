/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strisalnum.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tmatlena <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/08/28 13:20:09 by tmatlena          #+#    #+#             */
/*   Updated: 2018/08/28 13:20:13 by tmatlena         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/libft.h"

int		ft_strisalnum(char *str)
{
	int i;

	i = -1;
	while (str[++i] != '\0')
		if (!ft_isalpha(str[i]) && !ft_isdigit(str[i]))
			return (0);
	return (1);
}
