/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_tabdel.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tmatlena <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/08/28 14:55:48 by tmatlena          #+#    #+#             */
/*   Updated: 2018/08/28 14:55:52 by tmatlena         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/libft.h"

void	ft_tabdel(void **todel)
{
	int		i;

	i = 0;
	if (todel)
	{
		while (todel[i])
		{
			free(todel[i]);
			todel[i] = NULL;
			i++;
		}
		free(todel);
		todel = NULL;
	}
}
