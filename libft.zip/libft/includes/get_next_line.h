/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line.h                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tmatlena <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/08/28 10:42:25 by tmatlena          #+#    #+#             */
/*   Updated: 2018/08/28 10:42:35 by tmatlena         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef GET_NEXT_LINE_H
# define GET_NEXT_LINE_H

# define BUFF_SIZE 20
# include "libft.h"
# include <fcntl.h>

typedef struct			s_line
{
	char				*line;
	int					fd;
	struct s_line		*next;
}						t_line;

#endif
